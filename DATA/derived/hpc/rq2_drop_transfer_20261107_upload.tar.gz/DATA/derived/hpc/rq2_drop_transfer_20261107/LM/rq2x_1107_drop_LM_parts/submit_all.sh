#!/bin/bash
# Submits the 4 one-channel parts of rq2x_1107_drop_LM at once (scripts/seed_job_parallel.py split).
# The channels are independent: SLURM's own queue decides how many run together. Each part is the
# Seed page's chained seed job for one channel, so it resubmits itself if a channel outlasts the wall.
# Run from the repo root on the cluster (/home/Student/s4699158/CNN).
#
# Cancel them all:  squeue -u $USER -h -o "%i %j" | awk '$2 ~ /^rq2x_1107_drop_LM__/ {print $1}' | xargs -r scancel
# When every part is done, bring back DATA/derived/hpc/rq2_drop_transfer_20261107/LM/rq2x_1107_drop_LM_parts/*.result.json and on the PC run:
#   python scripts/seed_job_parallel.py merge DATA/derived/hpc/rq2_drop_transfer_20261107/LM/rq2x_1107_drop_LM.spec.json
# then import the merged result on the Seed page.
set -euo pipefail

sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/LM/rq2x_1107_drop_LM_parts/rq2x_1107_drop_LM__CH0.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/LM/rq2x_1107_drop_LM_parts/rq2x_1107_drop_LM__CH1.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/LM/rq2x_1107_drop_LM_parts/rq2x_1107_drop_LM__CH2.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/LM/rq2x_1107_drop_LM_parts/rq2x_1107_drop_LM__CH3.sh
