#!/bin/bash
# Submits the 16 one-channel parts of rq2x_1107_drop_MJu26a at once (scripts/seed_job_parallel.py split).
# The channels are independent: SLURM's own queue decides how many run together. Each part is the
# Seed page's chained seed job for one channel, so it resubmits itself if a channel outlasts the wall.
# Run from the repo root on the cluster (/home/Student/s4699158/CNN).
#
# Cancel them all:  squeue -u $USER -h -o "%i %j" | awk '$2 ~ /^rq2x_1107_drop_MJu26a__/ {print $1}' | xargs -r scancel
# When every part is done, bring back DATA/derived/hpc/rq2_drop_transfer_20261107/MJu26a/rq2x_1107_drop_MJu26a_parts/*.result.json and on the PC run:
#   python scripts/seed_job_parallel.py merge DATA/derived/hpc/rq2_drop_transfer_20261107/MJu26a/rq2x_1107_drop_MJu26a.spec.json
# then import the merged result on the Seed page.
set -euo pipefail

sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/MJu26a/rq2x_1107_drop_MJu26a_parts/rq2x_1107_drop_MJu26a__CH0.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/MJu26a/rq2x_1107_drop_MJu26a_parts/rq2x_1107_drop_MJu26a__CH1.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/MJu26a/rq2x_1107_drop_MJu26a_parts/rq2x_1107_drop_MJu26a__CH2.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/MJu26a/rq2x_1107_drop_MJu26a_parts/rq2x_1107_drop_MJu26a__CH3.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/MJu26a/rq2x_1107_drop_MJu26a_parts/rq2x_1107_drop_MJu26a__CH4.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/MJu26a/rq2x_1107_drop_MJu26a_parts/rq2x_1107_drop_MJu26a__CH5.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/MJu26a/rq2x_1107_drop_MJu26a_parts/rq2x_1107_drop_MJu26a__CH6.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/MJu26a/rq2x_1107_drop_MJu26a_parts/rq2x_1107_drop_MJu26a__CH7.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/MJu26a/rq2x_1107_drop_MJu26a_parts/rq2x_1107_drop_MJu26a__CH8.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/MJu26a/rq2x_1107_drop_MJu26a_parts/rq2x_1107_drop_MJu26a__CH9.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/MJu26a/rq2x_1107_drop_MJu26a_parts/rq2x_1107_drop_MJu26a__CH10.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/MJu26a/rq2x_1107_drop_MJu26a_parts/rq2x_1107_drop_MJu26a__CH11.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/MJu26a/rq2x_1107_drop_MJu26a_parts/rq2x_1107_drop_MJu26a__CH12.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/MJu26a/rq2x_1107_drop_MJu26a_parts/rq2x_1107_drop_MJu26a__CH13.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/MJu26a/rq2x_1107_drop_MJu26a_parts/rq2x_1107_drop_MJu26a__CH14.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/MJu26a/rq2x_1107_drop_MJu26a_parts/rq2x_1107_drop_MJu26a__CH15.sh
