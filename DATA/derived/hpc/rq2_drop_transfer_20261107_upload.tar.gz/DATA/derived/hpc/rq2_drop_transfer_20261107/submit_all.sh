#!/bin/bash
set -euo pipefail
cd /home/Student/s4699158/CNN
mkdir -p logs
source ~/miniconda3/etc/profile.d/conda.sh
conda activate aeon-env
python DATA/derived/hpc/rq2_drop_transfer_20261107/worker.py check --manifest DATA/derived/hpc/rq2_drop_transfer_20261107/manifest.json
QUEUED="$(squeue -u "$(id -un)" -h -o "%j")"
if printf '%s\n' "$QUEUED" | grep -q '^rq2x_1107_drop_'; then
    echo 'This transfer experiment already has jobs queued or running; not submitting duplicates.'
    exit 1
fi
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/M2_concat/rq2x_1107_drop_M2_concat_parts/rq2x_1107_drop_M2_concat__pack1of3.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/M2_concat/rq2x_1107_drop_M2_concat_parts/rq2x_1107_drop_M2_concat__pack2of3.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/M2_concat/rq2x_1107_drop_M2_concat_parts/rq2x_1107_drop_M2_concat__pack3of3.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/M4/rq2x_1107_drop_M4_parts/rq2x_1107_drop_M4__pack1of3.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/M4/rq2x_1107_drop_M4_parts/rq2x_1107_drop_M4__pack2of3.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/M4/rq2x_1107_drop_M4_parts/rq2x_1107_drop_M4__pack3of3.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/LM/rq2x_1107_drop_LM_parts/rq2x_1107_drop_LM__pack1of3.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/LM/rq2x_1107_drop_LM_parts/rq2x_1107_drop_LM__pack2of3.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/LM/rq2x_1107_drop_LM_parts/rq2x_1107_drop_LM__pack3of3.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/CO/rq2x_1107_drop_CO_parts/rq2x_1107_drop_CO__pack1of3.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/CO/rq2x_1107_drop_CO_parts/rq2x_1107_drop_CO__pack2of3.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/CO/rq2x_1107_drop_CO_parts/rq2x_1107_drop_CO__pack3of3.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/MJu26a/rq2x_1107_drop_MJu26a_parts/rq2x_1107_drop_MJu26a__pack1of3.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/MJu26a/rq2x_1107_drop_MJu26a_parts/rq2x_1107_drop_MJu26a__pack2of3.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/MJu26a/rq2x_1107_drop_MJu26a_parts/rq2x_1107_drop_MJu26a__pack3of3.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/SH/rq2x_1107_drop_SH_parts/rq2x_1107_drop_SH__pack1of3.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/SH/rq2x_1107_drop_SH_parts/rq2x_1107_drop_SH__pack2of3.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/SH/rq2x_1107_drop_SH_parts/rq2x_1107_drop_SH__pack3of3.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/SO/rq2x_1107_drop_SO_parts/rq2x_1107_drop_SO__pack1of3.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/SO/rq2x_1107_drop_SO_parts/rq2x_1107_drop_SO__pack2of3.sh
sbatch DATA/derived/hpc/rq2_drop_transfer_20261107/SO/rq2x_1107_drop_SO_parts/rq2x_1107_drop_SO__pack3of3.sh
