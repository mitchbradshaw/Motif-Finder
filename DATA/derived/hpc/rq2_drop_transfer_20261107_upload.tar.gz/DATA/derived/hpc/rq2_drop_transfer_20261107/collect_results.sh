#!/bin/bash
set -euo pipefail
cd /home/Student/s4699158/CNN
source ~/miniconda3/etc/profile.d/conda.sh
conda activate aeon-env
python DATA/derived/hpc/rq2_drop_transfer_20261107/worker.py collect --manifest DATA/derived/hpc/rq2_drop_transfer_20261107/manifest.json
